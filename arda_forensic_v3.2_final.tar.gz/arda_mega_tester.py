import subprocess
import os
import struct
import json
import time
import sys

def run(cmd, shell=False, capture=True):
    try:
        if capture:
            return subprocess.check_output(cmd, shell=shell, text=True, stderr=subprocess.STDOUT)
        else:
            subprocess.check_call(cmd, shell=shell)
            return ""
    except subprocess.CalledProcessError as e:
        if capture:
            return e.output
        else:
            raise

def main():
    log_path = "arda_os/attestation/mega_test_v3.2.log"
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    
    with open(log_path, "w") as log_file:
        def log(msg):
            print(msg)
            log_file.write(msg + "\n")
            log_file.flush()

        log("\n" + "="*50)
        log("   ARDA OS: ULTIMATE SOVEREIGN MEGA TESTER (v3.2)")
        log("="*50)
        
        try:
            # 0. BOMBADIL PRE-FLIGHT (Hard Stop)
            log("[0] Bombadil Law Daemon: Sovereign Audit...")
            bombadil_check = run("python3 arda_os/backend/services/arda_bombadil.py --check", shell=True)
            log(bombadil_check)
            
            # User Feedback: Hard-stop if constitutional state is broken
            if "Covenant State:  severed" in bombadil_check:
                log("FATAL: Constitutional Covenant is SEVERED. Substrate compromise detected.")
                log("Aborting to prevent Ring-0 lockout on a broken system.")
                return
            
            if "BPF object:      present" not in bombadil_check:
                log("FATAL: BPF object missing. Policy cannot be enforced.")
                return
            
            log("INFO: Substrate audit passed. Proceeding to MEGA TEST.")

            # 1. CLEANUP (Thorough)
            log("[1] Cleaning up previous BPF objects...")
            subprocess.call("sudo rm -f /sys/fs/bpf/arda_lsm_link /sys/fs/bpf/arda_harmony /sys/fs/bpf/arda_state /sys/fs/bpf/arda_phy_rodata /sys/fs/bpf/arda_lsm", shell=True)
            
            # 2. COMPILE BPF
            log("[2] Compiling BPF LSM program...")
            run("clang -O2 -g -target bpf -D__TARGET_ARCH_x86 -c bpf/arda_physical_lsm.c -o bpf/arda_physical_lsm.o", shell=True)
            if not os.path.exists("bpf/arda_physical_lsm.o"):
                log("FATAL: Compilation failed.")
                return

            # 3. LOAD & ATTACH
            log("[3] Loading and Attaching BPF via C Ignitor...")
            ignitor_out = run("sudo ./arda_os/arda_sovereign_ignitor bpf/arda_physical_lsm.o", shell=True)
            log(ignitor_out)
            
            if "SUCCESS" not in ignitor_out:
                log("FATAL: Ignitor failed to load program.")
                return
            
            if not os.path.exists("/sys/fs/bpf/arda_harmony") or not os.path.exists("/sys/fs/bpf/arda_state"):
                 log("FATAL: Pinned maps not found after attachment.")
                 return
            log("SUCCESS: Arda LSM Attached and Maps Pinned.")

            # 4. SAFETY SEEDING & VERIFICATION
            log("[4] Safety Seeding and Policy Verification...")
            critical_bins = [
                "/bin/bash", "/bin/ls", "/bin/cat", "/bin/grep", "/bin/chmod", "/bin/cp", "/bin/rm",
                "/usr/bin/sudo", "/usr/bin/python3", "/usr/sbin/bpftool", "/usr/bin/stat", "/usr/bin/id"
            ]
            for b in critical_bins:
                if os.path.exists(b):
                    s = os.stat(b)
                    maj = os.major(s.st_dev)
                    min = os.minor(s.st_dev)
                    k_dev = (maj << 20) | min
                    
                    # Layout: u64 inode (8), u32 dev (4), u32 pad (4) = 16 bytes
                    k_bytes = struct.pack("<QII", s.st_ino, k_dev, 0)
                    k_hex = " ".join([f"{b:02x}" for b in k_bytes])
                    
                    # Update Map (Use hex for total byte-level control)
                    run(f"sudo bpftool map update pinned /sys/fs/bpf/arda_harmony key hex {k_hex} value hex 01 00 00 00", shell=True)
                    
                    # VERIFICATION: Immediately lookup to confirm persistence
                    lookup = run(f"sudo bpftool map lookup pinned /sys/fs/bpf/arda_harmony key hex {k_hex}", shell=True)
                    if "value" not in lookup.lower():
                        log(f"FATAL: Map lookup failed immediately after seeding for {b}!")
                        log(f"Seeding hex: {k_hex}")
                        log(f"Raw lookup output: '{lookup}'")
                        return
                    log(f"  Safely Seeded & Verified: {b} (ino={s.st_ino}, dev={k_dev})")
                    log(f"    Hex: {k_hex}")

            # 5. AUDIT-FIRST VERIFICATION
            log("[5] Phase A: Audit-First Verification (Dry Run)...")
            run("sudo bpftool map update pinned /sys/fs/bpf/arda_state key hex 00 00 00 00 value hex 00 00 00 00", shell=True)
            
            if os.path.exists("/sys/kernel/debug/tracing/trace"):
                subprocess.call("sudo truncate -s 0 /sys/kernel/debug/tracing/trace", shell=True)
            
            log("  Executing heart-beat tests for authorized set...")
            for b in critical_bins:
                if "bpftool" in b: continue # Skip self
                subprocess.run([b, "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Check for "Targeted Policy Retrieval Failure"
            if os.path.exists("/sys/kernel/debug/tracing/trace"):
                trace_content = run("sudo cat /sys/kernel/debug/tracing/trace", shell=True)
                
                # We strictly check if any of our authorized binary INODES were denied
                targeted_denials = []
                for b in critical_bins:
                    if os.path.exists(b):
                        ino = os.stat(b).st_ino
                        if f"would deny execution for inode {ino}" in trace_content:
                            targeted_denials.append(f"{b} (ino={ino})")
                
                if targeted_denials:
                    log("FATAL: Policy Retrieval Failure for TARGETED binaries!")
                    for d in targeted_denials: log(f"  > {d}")
                    log("Full trace for analysis:")
                    log(trace_content)
                    return
            
            log("SUCCESS: Audit phase passed. Authorized identities are alive in Ring-0.")
            
            # 6. ACTIVATE ENFORCEMENT & SENTINEL
            log("[6] Phase B: Activating Enforced Mode...")
            
            log("  Spawning Safety Sentinel (60s fallback)...")
            sentinel_cmd = "sleep 60 && sudo bpftool map update pinned /sys/fs/bpf/arda_state key hex 00 00 00 00 value hex 00 00 00 00"
            subprocess.Popen(sentinel_cmd, shell=True, start_new_session=True)

            run("sudo bpftool map update pinned /sys/fs/bpf/arda_state key hex 00 00 00 00 value hex 01 00 00 00", shell=True)
            log("  RING-0 ENFORCEMENT ACTIVE.")

            # 7. PROOF
            log("\n" + "-"*50 + "\n   THE SOVEREIGN PROOF\n" + "-"*50)
            time.sleep(1)
            
            log("[TEST 1] Authorized Binary (/bin/ls)...")
            try:
                subprocess.check_call(["/bin/ls", "/tmp"], stdout=subprocess.DEVNULL)
                log("  RESULT: SUCCESS (Permitted)")
            except Exception as e:
                log(f"  RESULT: FAILED ({e})")

            log("[TEST 2] Unauthorized Binary (/tmp/arda_unauth)...")
            subprocess.call("cp /bin/ls /tmp/arda_unauth && chmod +x /tmp/arda_unauth", shell=True)
            try:
                res = subprocess.run(["/tmp/arda_unauth", "/tmp"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if res.returncode != 0:
                    log(f"  RESULT: SUCCESS (Blocked with code {res.returncode})")
                else:
                    log("  RESULT: FAILED (Bypass!)")
            except Exception as e:
                log(f"  RESULT: SUCCESS (Blocked by exception: {e})")

        except Exception as global_e:
            log(f"FATAL ERROR during test: {global_e}")

        finally:
            if os.path.exists("/sys/fs/bpf/arda_state"):
                log("\n[SAFETY] Deactivating Ring-0 Enforcement...")
                subprocess.call("sudo bpftool map update pinned /sys/fs/bpf/arda_state key 0 0 0 0 value 0 0 0 0", shell=True)
                log("  Sovereignty state set to AUDIT (Permissive).")
            
            # Dump the map for forensics
            log("[FINAL] Dumping Harmony Map for forensic record...")
            run("sudo bpftool map dump pinned /sys/fs/bpf/arda_harmony j > arda_os/attestation/harmony_map_sovereign_dump.json", shell=True)
            
            log("\n" + "="*50 + "\n   MEGA TEST v3.2 COMPLETE\n" + "="*50)

if __name__ == "__main__":
    main()
