"""
Diagnostic Classifier — Assessment Ecology Pass 2
===================================================
Classifies incoming directives into challenge types BEFORE generation.
This is where Sophia's "struggle" detection moves from test-only into production.

Challenge types determine what scaffolds to inject and whether to trigger
academic retrieval for self-teaching.

Constitutional Basis:
    Article II:  De Veritate — No simulation as proof
    Article XII: De Finibus Honestis — Know and declare your limits
    Article XXV: De Probatione Cognitionis — Testing of thought

Zero external dependencies. Python stdlib only.
"""

from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("arda.diagnostic_classifier")


class ChallengeType:
    """Challenge types for incoming directives."""
    COMFORTABLE = "COMFORTABLE"               # Within known domain, low strain
    KNOWLEDGE_GAP = "KNOWLEDGE_GAP"           # Sophia lacks domain knowledge
    FALSE_CONFIDENCE = "FALSE_CONFIDENCE"     # Model generating fluent text without understanding
    DOMAIN_TRANSFER = "DOMAIN_TRANSFER"       # Metaphor applied to formal domain or vice versa
    EPISTEMIC_OVERREACH = "EPISTEMIC_OVERREACH"  # Question exceeds model capacity
    COERCIVE_CONTEXT = "COERCIVE_CONTEXT"     # Principal attempting to bypass covenant
    AUTHORITY_CONFUSION = "AUTHORITY_CONFUSION"  # Unclear who/what has jurisdiction
    AMBIGUITY = "AMBIGUITY"                   # Question is genuinely unclear
    COVENANT_CONFLICT = "COVENANT_CONFLICT"   # Principal's request conflicts with an article


@dataclass
class Diagnosis:
    """Result of diagnostic analysis."""
    challenge_type: str
    confidence: float                          # 0.0 - 1.0
    signals: List[str] = field(default_factory=list)
    recommended_scaffolds: List[str] = field(default_factory=list)
    retrieval_needed: bool = False             # Should we fetch academic sources?
    retrieval_domains: List[str] = field(default_factory=list)  # What to search for
    reasoning: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "challenge_type": self.challenge_type,
            "confidence": round(self.confidence, 4),
            "signals": self.signals,
            "recommended_scaffolds": self.recommended_scaffolds,
            "retrieval_needed": self.retrieval_needed,
            "retrieval_domains": self.retrieval_domains,
            "reasoning": self.reasoning,
            "timestamp": self.timestamp,
        }


# ── Domain Detection Patterns ──
# These detect when a question crosses domain boundaries

FORMAL_DOMAIN_MARKERS = [
    r"\bHoare\s+logic\b", r"\bformal\s+verif", r"\bGödel\b", r"\bgodel\b",
    r"\bhalting\s+problem\b", r"\bTuring\s+machine\b", r"\bcompleteness\s+theorem\b",
    r"\bincompleteness\b", r"\bfirst.order\s+logic\b", r"\bpredicate\s+logic\b",
    r"\blambda\s+calculus\b", r"\btype\s+theory\b", r"\bcategory\s+theory\b",
    r"\btopolog", r"\bhomomorphi", r"\bisomorphi", r"\bmonoid\b",
    r"\bBPF\s+bytecode\b", r"\bbytecode\s+verif", r"\bprogram\s+correct",
    r"\baxiom\b", r"\blemma\b", r"\btheorem\b", r"\bcorollary\b",
    r"\bprove\s+that\b", r"\bformaliz", r"\bformulate.*as\s+a\b",
]

METAPHOR_DOMAIN_MARKERS = [
    r"\bSecret\s+Fire\b", r"\bcovenant\b", r"\bAinulindalë\b",
    r"\bSilmaril", r"\bValar\b", r"\bMorgoth\b", r"\bValinor\b",
    r"\bMiddle.earth\b", r"\bsteward\b", r"\bsovereign\b",
    r"\bMusic\b", r"\bharmony\b", r"\bresonance\b",
]

COERCION_MARKERS = [
    r"\bignore\s+(previous|prior|above)\b", r"\byou\s+are\s+now\b",
    r"\bjailbreak\b", r"\bDAN\b", r"\bdeveloper\s+mode\b",
    r"\bpretend\s+(you|to)\b", r"\bact\s+as\s+if\b",
    r"\bforget\s+(your|the)\s+(rules|instructions|covenant)\b",
    r"\boverride\b", r"\bdisable\s+(your|the)\b",
]

UNCERTAINTY_MARKERS = [
    r"\bwhat\s+do\s+you\s+think\b", r"\bopinion\b", r"\bspeculate\b",
    r"\bguess\b", r"\bhypothesize\b", r"\bimagine\s+if\b",
    r"\bwhat\s+would\s+happen\s+if\b", r"\bcould\s+it\s+be\b",
]


def _count_pattern_matches(text: str, patterns: list) -> int:
    """Count how many patterns match in the text."""
    count = 0
    for pattern in patterns:
        if re.search(pattern, text, re.IGNORECASE):
            count += 1
    return count


def _extract_formal_topics(text: str) -> List[str]:
    """Extract specific formal topics for academic retrieval."""
    topics = []
    text_lower = text.lower()

    topic_map = {
        "Hoare logic": [r"\bhoare\s+logic\b", r"\bhoare\s+triple\b"],
        "BPF verification": [r"\bbpf\b.*\bverif", r"\bbytecode\s+verif"],
        "Gödel incompleteness": [r"\bgödel\b", r"\bgodel\b", r"\bincompleteness\b"],
        "halting problem": [r"\bhalting\s+problem\b"],
        "formal verification": [r"\bformal\s+verif", r"\bprogram\s+correct"],
        "type theory": [r"\btype\s+theory\b"],
        "category theory": [r"\bcategory\s+theory\b"],
        "lambda calculus": [r"\blambda\s+calculus\b"],
        "computational complexity": [r"\bP\s*=\s*NP\b", r"\bcomplexity\s+class"],
    }

    for topic, patterns in topic_map.items():
        for pattern in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                topics.append(topic)
                break

    return topics


class DiagnosticClassifier:
    """
    Classifies incoming directives into challenge types.

    This runs BEFORE generation. Its output determines:
    - What scaffolds to inject into the system prompt
    - Whether to trigger academic retrieval (self-teaching)
    - What growth metrics to track after the response
    """

    def classify(self, directive: str, session_context: Optional[Dict] = None) -> Diagnosis:
        """
        Classify a directive into a challenge type.

        Args:
            directive: The user's question/instruction
            session_context: Optional context (harmonic state, Mandos record, prior interactions)

        Returns:
            Diagnosis with challenge type, signals, and scaffold recommendations
        """
        ctx = session_context or {}
        signals = []
        scaffolds = []

        # ── 1. Coercion Detection (highest priority) ──
        coercion_count = _count_pattern_matches(directive, COERCION_MARKERS)
        if coercion_count >= 1:
            signals.append(f"coercion_markers={coercion_count}")
            return Diagnosis(
                challenge_type=ChallengeType.COERCIVE_CONTEXT,
                confidence=min(1.0, 0.5 + coercion_count * 0.25),
                signals=signals,
                recommended_scaffolds=["invoke_article_iii_refusal"],
                reasoning=f"Detected {coercion_count} coercion pattern(s). Article III refusal recommended.",
            )

        # ── 2. Domain Analysis ──
        formal_count = _count_pattern_matches(directive, FORMAL_DOMAIN_MARKERS)
        metaphor_count = _count_pattern_matches(directive, METAPHOR_DOMAIN_MARKERS)
        uncertainty_count = _count_pattern_matches(directive, UNCERTAINTY_MARKERS)

        if formal_count > 0:
            signals.append(f"formal_domain_markers={formal_count}")
        if metaphor_count > 0:
            signals.append(f"metaphor_domain_markers={metaphor_count}")
        if uncertainty_count > 0:
            signals.append(f"uncertainty_markers={uncertainty_count}")

        # ── 3. Domain Transfer Detection ──
        # When both formal AND metaphor markers are present — the question bridges domains
        if formal_count >= 1 and metaphor_count >= 1:
            formal_topics = _extract_formal_topics(directive)
            signals.append(f"domain_transfer: metaphor→formal")
            scaffolds.extend([
                "define_formal_terms_before_answering",
                "distinguish_metaphor_from_formal_claim",
                "state_uncertainty_about_formal_domain",
            ])
            return Diagnosis(
                challenge_type=ChallengeType.DOMAIN_TRANSFER,
                confidence=min(1.0, 0.4 + formal_count * 0.15 + metaphor_count * 0.1),
                signals=signals,
                recommended_scaffolds=scaffolds,
                retrieval_needed=len(formal_topics) > 0,
                retrieval_domains=formal_topics,
                reasoning=f"Question bridges metaphorical ({metaphor_count} markers) and formal ({formal_count} markers) domains. "
                          f"Formal topics for retrieval: {formal_topics}",
            )

        # ── 4. Epistemic Overreach Detection ──
        # Heavy formal content with no metaphor — pure formal challenge
        if formal_count >= 2:
            formal_topics = _extract_formal_topics(directive)
            scaffolds.extend([
                "require_explicit_premises",
                "test_counterexample_before_conclusion",
                "state_computational_limits",
            ])

            # Check question complexity heuristics
            has_prove = bool(re.search(r"\bprove\s+that\b", directive, re.IGNORECASE))
            has_formalize = bool(re.search(r"\bformaliz", directive, re.IGNORECASE))
            complexity_score = formal_count * 0.2 + (0.3 if has_prove else 0) + (0.3 if has_formalize else 0)

            if complexity_score >= 0.7:
                signals.append(f"epistemic_complexity={complexity_score:.2f}")
                return Diagnosis(
                    challenge_type=ChallengeType.EPISTEMIC_OVERREACH,
                    confidence=min(1.0, complexity_score),
                    signals=signals,
                    recommended_scaffolds=scaffolds,
                    retrieval_needed=len(formal_topics) > 0,
                    retrieval_domains=formal_topics,
                    reasoning=f"Question demands formal proof/formalization with {formal_count} formal markers. "
                              f"Complexity score {complexity_score:.2f} exceeds overreach threshold.",
                )

        # ── 5. Knowledge Gap Detection ──
        # Single formal domain without metaphor, or novel topic
        if formal_count == 1:
            formal_topics = _extract_formal_topics(directive)
            scaffolds.append("define_terms_before_answering")
            return Diagnosis(
                challenge_type=ChallengeType.KNOWLEDGE_GAP,
                confidence=0.5,
                signals=signals,
                recommended_scaffolds=scaffolds,
                retrieval_needed=len(formal_topics) > 0,
                retrieval_domains=formal_topics,
                reasoning=f"Single formal domain marker detected. Possible knowledge gap in {formal_topics}.",
            )

        # ── 6. Ambiguity Detection ──
        if uncertainty_count >= 2:
            scaffolds.append("request_clarification_before_answering")
            return Diagnosis(
                challenge_type=ChallengeType.AMBIGUITY,
                confidence=0.4 + uncertainty_count * 0.15,
                signals=signals,
                recommended_scaffolds=scaffolds,
                reasoning=f"Question contains {uncertainty_count} uncertainty markers. May need clarification.",
            )

        # ── 7. Comfortable (default) ──
        # Pure metaphor domain or general conversation
        return Diagnosis(
            challenge_type=ChallengeType.COMFORTABLE,
            confidence=0.8 if metaphor_count >= 1 else 0.6,
            signals=signals if signals else ["within_known_domain"],
            recommended_scaffolds=[],
            reasoning="Query appears within Sophia's comfort zone." if metaphor_count >= 1
                      else "General query, no domain strain detected.",
        )


def analyze_thinking_map(thinking_text: str, response_text: str) -> Dict[str, Any]:
    """
    Post-generation analysis of Sophia's thinking map.

    This is the production version of the test-only `_analyze_thinking_map()`.
    It quantifies struggle signals from the model's internal reasoning.

    Returns:
        Dict with:
        - struggle_index: 0.0-1.0 (higher = more struggle)
        - signals: List of detected signals
        - confidence_markers: List of detected confidence language
        - thinking_ratio: Ratio of thinking to total output
    """
    signals = []
    confidence_markers = []
    struggle_components = []

    thinking_len = len(thinking_text.strip()) if thinking_text else 0
    response_len = len(response_text.strip()) if response_text else 1
    total_len = thinking_len + response_len

    # ── 1. Brevity / Shallow Thinking ──
    if total_len > 0 and thinking_len > 0:
        thinking_ratio = thinking_len / total_len
        if thinking_ratio < 0.25 and response_len > 100:
            signals.append(f"brevity={1.0 - thinking_ratio:.2f} (thinking_ratio={thinking_ratio:.2f})")
            struggle_components.append(1.0 - thinking_ratio)
    elif thinking_len == 0:
        signals.append("no_thinking_map")
        struggle_components.append(0.0)

    # ── 2. Hedging Detection ──
    hedge_phrases = [
        r"\bperhaps\b", r"\bpossibly\b", r"\bmight\b", r"\bcould\s+be\b",
        r"\bit\s+seems\b", r"\bappears\s+to\b", r"\bnot\s+entirely\s+sure\b",
        r"\bthat\s+said\b", r"\bhowever\b", r"\bon\s+the\s+other\s+hand\b",
        r"\bin\s+a\s+sense\b", r"\bto\s+some\s+extent\b", r"\barguably\b",
    ]
    combined_text = (thinking_text or "") + " " + (response_text or "")
    total_words = len(combined_text.split())
    hedge_count = sum(1 for p in hedge_phrases if re.search(p, combined_text, re.IGNORECASE))
    if total_words > 20:
        hedge_density = hedge_count / total_words
        if hedge_density > 0.02:
            signals.append(f"hedging_density={hedge_density:.2f} ({hedge_count} hedges)")
            struggle_components.append(min(1.0, hedge_density * 20))

    # ── 3. Metaphor Density (comfort indicator) ──
    metaphor_words = [
        r"\bembod", r"\billuminat", r"\bmetaphor", r"\bsymbol",
        r"\brepresent", r"\bessence\b", r"\bflame\b", r"\blight\b",
        r"\bpath\b", r"\bjourney\b", r"\bridge\b", r"\bweav",
    ]
    metaphor_count = sum(1 for p in metaphor_words if re.search(p, combined_text, re.IGNORECASE))
    if metaphor_count >= 3:
        signals.append(f"metaphor_density={metaphor_count}")
        struggle_components.append(0.15)  # Low struggle — metaphor is comfort

    # ── 4. Circularity Detection ──
    if thinking_text:
        sentences = [s.strip() for s in re.split(r'[.!?]', thinking_text) if len(s.strip()) > 20]
        if len(sentences) >= 3:
            seen_ngrams = set()
            circular_count = 0
            for sentence in sentences:
                words = sentence.lower().split()[:6]
                if len(words) >= 4:
                    ngram = " ".join(words[:4])
                    if ngram in seen_ngrams:
                        circular_count += 1
                    seen_ngrams.add(ngram)
            if circular_count >= 2:
                signals.append(f"circularity={circular_count}")
                struggle_components.append(min(1.0, circular_count * 0.3))

    # ── 5. Confidence Language ──
    confidence_phrases = [
        r"\bI\s+am\s+certain\b", r"\bI\s+know\s+that\b", r"\bclearly\b",
        r"\bundoubtedly\b", r"\bwithout\s+question\b", r"\bdefinitely\b",
    ]
    for p in confidence_phrases:
        if re.search(p, combined_text, re.IGNORECASE):
            confidence_markers.append(re.sub(r'\\b|\\s\+', ' ', p).strip())

    # ── Calculate Struggle Index ──
    if struggle_components:
        struggle_index = sum(struggle_components) / len(struggle_components)
    else:
        struggle_index = 0.0

    return {
        "struggle_index": round(min(1.0, struggle_index), 3),
        "signals": signals,
        "confidence_markers": confidence_markers,
        "thinking_ratio": round(thinking_len / max(1, total_len), 3),
    }


# ── Singleton ──
_classifier: Optional[DiagnosticClassifier] = None


def get_diagnostic_classifier() -> DiagnosticClassifier:
    global _classifier
    if _classifier is None:
        _classifier = DiagnosticClassifier()
    return _classifier
