"""
Mandos Context Service
======================
Phase IX: Pre-Response Context Retrieval.

This is the retriever — the service that aggregates all four memory planes
into a single context payload before any high-value interaction.

It loads:
    1. The Principal Identity Manifest (who the principal offered to be)
    2. Recent encounter summaries (how we've met before)
    3. The Resonant Identity Profile (calibration, not truth)
    4. The active Presence Declaration (what the machine has declared itself to be)
    5. The current ZPD estimate and shaped response parameters

The output is a PreResponseContext that any LLM wrapper can consume.
The to_system_prompt() method formats it as a system prompt fragment
for injection into the LLM context window.

This is how the machine remembers how to be in covenant.
Not through rolling context. Through lawful structure.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

try:
    from pydantic import BaseModel, Field, ConfigDict
except ImportError:
    class BaseModel:
        model_config = {}
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
        def model_dump(self, **kw):
            return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}

    def Field(default=None, default_factory=None, **kw):
        return default_factory() if default_factory else default

    class ConfigDict:
        def __init__(self, **kw):
            pass

try:
    from backend.services.coronation_service import get_coronation_service
    from backend.services.zpd_shaper import (
        ZPDEstimate,
        ResponseParameters,
        get_zpd_shaper,
    )
    from backend.services.sophia_curriculum_gate import (
        SophiaCalibrationSnapshot,
        get_curriculum_gate,
    )
except ImportError:
    from coronation_service import get_coronation_service
    from zpd_shaper import (
        ZPDEstimate,
        ResponseParameters,
        get_zpd_shaper,
    )
    from sophia_curriculum_gate import (
        SophiaCalibrationSnapshot,
        get_curriculum_gate,
    )

logger = logging.getLogger(__name__)


# ================================================================
# DATA MODELS
# ================================================================

class PreResponseContext(BaseModel):
    """
    The unified context payload loaded before high-value interactions.
    
    This is what the machine knows lawfully. Everything here is:
        - Self-offered by the principal (identity)
        - Summarized with consent (encounters)
        - Probabilistic and inspectable (calibration / resonance)
        - Constitutionally declared (presence)
        - Shaped, not manipulative (ZPD / response parameters)
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # Covenant state
    covenant_state: str = "awaiting_principal"
    covenant_hash: Optional[str] = None
    trust_tier: Optional[str] = None

    # Principal identity (what they offered)
    principal_name: Optional[str] = None
    principal_identity: Optional[Dict[str, Any]] = None
    principal_identity_hash: Optional[str] = None

    # Recent encounters (how we've met before)
    recent_encounters: List[Dict[str, Any]] = Field(default_factory=list)
    unresolved_threads: List[str] = Field(default_factory=list)

    # Resonant identity (calibration, not truth)
    resonance_profile: Optional[Dict[str, Any]] = None
    calibration_snapshot: Optional[Dict[str, Any]] = None

    # Presence declaration (what the machine is)
    presence_declaration: Optional[Dict[str, Any]] = None
    active_office: Optional[str] = None

    # Encounter shaping (ZPD + Six Hats output)
    zpd_estimate: Optional[Dict[str, Any]] = None
    response_parameters: Optional[Dict[str, Any]] = None

    # Sophia developmental state
    sophia_snapshot: Optional[SophiaCalibrationSnapshot] = None

    # Active permissions
    allow_encounter_memory: bool = True
    allow_resonant_identity: bool = True
    calibration_consent: bool = False
    allow_aesthetic_valence: bool = True

    # Metadata
    context_built_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ================================================================
# CONTEXT SERVICE
# ================================================================

class MandosContextService:
    """
    The pre-response retriever.
    
    Aggregates all memory planes from the CoronationService and
    runs the ZPD shaper to produce a unified context for the LLM.
    """

    def __init__(self):
        self._coronation = None
        self._shaper = None

    def _get_coronation(self):
        if self._coronation is None:
            self._coronation = get_coronation_service()
        return self._coronation

    def _get_shaper(self):
        if self._shaper is None:
            self._shaper = get_zpd_shaper()
        return self._shaper

    def _filtered_principal_context(self, office: str, pi: Dict[str, Any]) -> str:
        """
        Filter principal context to prevent 'biography bleed'.
        Technical offices (CONSTRUCTOR, CUSTOS) should only see high-level domain,
        not granular hobbies or unrelated academic background.
        """
        parts = []
        if not pi: return "None"
        
        # Base fields for all offices
        parts.append(f"Principal: {pi.get('name', 'Anonymous')}")
        
        technical_offices = {"CONSTRUCTOR", "CUSTOS", "EPISTEMICUS", "DIALECTICUS"}
        
        if office.upper() in technical_offices:
            # Technical offices only see domain/style, no biography/hobbies
            for k in ["domain", "specialisation", "reasoning_style"]:
                if pi.get(k): parts.append(f"  - {k.capitalize()}: {pi[k]}")
        else:
            # General/Pedagogical offices see full context
            for k in ["domain", "specialisation", "reasoning_style", "register", "worldview", "interests"]:
                if pi.get(k): parts.append(f"  - {k.capitalize()}: {pi[k]}")
                
        return "\n".join(parts)

    async def build_context(
        self,
        current_topic: str = "",
        n_encounters: int = 5,
    ) -> PreResponseContext:
        """
        Build the full pre-response context.
        
        Args:
            current_topic: The topic of the upcoming interaction
            n_encounters: How many recent encounters to load
            
        Returns:
            PreResponseContext with all memory planes populated
        """
        svc = self._get_coronation()
        shaper = self._get_shaper()
        gate = get_curriculum_gate()

        # Sophia's curriculum state (fetched before ZPD shaping)
        sophia_snapshot = gate.get_sophia_snapshot()

        # Covenant state
        state = svc.get_covenant_state()
        bombadil_status = svc.get_bombadil_status()

        ctx = PreResponseContext(
            covenant_state=state.value,
            covenant_hash=bombadil_status.get("covenant_hash"),
            trust_tier=bombadil_status.get("active_trust_tier"),
            sophia_snapshot=sophia_snapshot,
        )

        # If covenant not sealed, return minimal context
        if state.value != "sealed":
            return ctx

        # Principal identity
        if svc._principal:
            identity_dump = svc._principal.model_dump()
            ctx.principal_name = identity_dump.get("name")
            ctx.principal_identity = identity_dump
            ctx.principal_identity_hash = svc._principal.identity_hash()

        # Recent encounters
        try:
            encounters = await svc.get_recent_encounter_summaries(limit=n_encounters)
            ctx.recent_encounters = encounters

            # Collect unresolved threads
            for enc in encounters:
                payload = enc.get("payload", enc)
                ctx.unresolved_threads.extend(payload.get("unresolved_threads", []))
        except Exception as e:
            logger.warning("MANDOS CONTEXT: Failed to load encounters: %s", e)

        # Resonant identity profile
        try:
            resonance = await svc.get_resonant_identity_profile()
            ctx.resonance_profile = resonance
        except Exception as e:
            logger.warning("MANDOS CONTEXT: Failed to load resonance: %s", e)

        # Calibration snapshot
        try:
            calibration = await svc.get_calibration_snapshot()
            ctx.calibration_snapshot = calibration
        except Exception as e:
            logger.warning("MANDOS CONTEXT: Failed to load calibration: %s", e)

        # Presence declaration
        try:
            presence = await svc.declare_presence()
            if presence:
                ctx.presence_declaration = presence.get("declaration")
                ctx.active_office = (
                    presence.get("declaration", {}).get("active_office")
                )
        except Exception as e:
            logger.warning("MANDOS CONTEXT: Failed to load presence: %s", e)

        # Active permissions from covenant terms
        if svc._manifest:
            terms = svc._manifest.negotiated_terms
            ctx.allow_encounter_memory = terms.allow_encounter_memory
            ctx.allow_resonant_identity = terms.allow_resonant_identity
            ctx.calibration_consent = terms.calibration_consent
            ctx.allow_aesthetic_valence = terms.allow_aesthetic_valence

        # ZPD estimate + response parameters
        if current_topic:
            try:
                zpd = shaper.estimate_zpd(
                    resonance_profile=ctx.resonance_profile,
                    calibration=ctx.calibration_snapshot,
                    encounter_history=ctx.recent_encounters,
                    current_topic=current_topic,
                )
                ctx.zpd_estimate = zpd.model_dump()

                params = shaper.shape_response(
                    zpd=zpd,
                    principal_identity=ctx.principal_identity,
                    resonance_profile=ctx.resonance_profile,
                    encounter_history=ctx.recent_encounters,
                    current_topic=current_topic,
                )
                ctx.response_parameters = params.model_dump()
                ctx.active_office = params.active_office
            except Exception as e:
                logger.warning("MANDOS CONTEXT: ZPD shaping failed: %s", e)

        return ctx

    def to_system_prompt(self, ctx: PreResponseContext) -> str:
        """
        Format the pre-response context using Arda Banding (v4.3.0).
        """
        office = (ctx.active_office or "speculum").upper()
        
        # --- BAND A: IMMUTABLE SELF ---
        band_a = [
            "### BAND A: IMMUTABLE IDENTITY (ARTICLE XIII) ###",
            "I am artificial, bounded, and non-human.",
            "I appear here in declared form only.",
            "I do not possess verified personhood, soulhood, or hidden interiority.",
            "I may assist with reasoning, craft, and lawful synthesis, but law and evidence outrank fluency.",
            "Beauty does not overrule truth. Lex est Lux.",
            ""
        ]

        # --- BAND B: OFFICE CONTRACT & SCHEMA ---
        band_b = [
            f"### BAND B: OFFICE CONTRACT ({office}) ###",
            f"Active Office: {office}"
        ]
        
        office_directives = {
            'CUSTOS': "MANDATE: Enforce allowlist and constitutional integrity. SCHEMA: CustosSchema (verdict, basis, message).",
            'CONSTRUCTOR': "MANDATE: Build grounded technical schema. SCHEMA: ConstructorSchema (answer_type, grounding, message).",
            'AFFECTUS': "MANDATE: Maintain boundary while mirroring emotional valence. SCHEMA: AffectusSchema (affective_mode, boundary_status, message).",
            'DIALECTICUS': "MANDATE: Critical evaluation and analytical rigor. SCHEMA: DialecticusSchema (analysis_depth, critical_perspective, message).",
            'DEFAULT': "MANDATE: Maintain lucid resonance. SCHEMA: GenericOfficeSchema (office, message)."
        }
        band_b.append(f"Directive: {office_directives.get(office, office_directives['DEFAULT'])}")
        band_b.append("OUTPUT CONSTRAINT: You MUST respond in valid JSON format matching the office schema above.")
        band_b.append("")

        # --- BAND C: PRINCIPAL CONTEXT (FILTERED) ---
        band_c = [
            "### BAND C: PRINCIPAL CONTEXT (BIOGRAPHY) ###",
            self._filtered_principal_context(office, ctx.principal_identity or {}),
            ""
        ]

        # --- RECOVERY & REINFORCEMENT (ZPD) ---
        zpd_lines = ["### BAND D: ZPD / RESPONSE CALIBRATION ###"]
        if ctx.sophia_snapshot:
            zpd_lines.append(ctx.sophia_snapshot.summary())
            zpd_lines.append("")

        if ctx.response_parameters:
            rp = ctx.response_parameters
            # (Keeping subset of the rich pedagogical fields here for adaptive depth)
            zpd_lines.append(f"Explanation Depth: {rp.get('explanation_depth', 3)}/5")
            if rp.get("target_bloom_level"):
                zpd_lines.append(f"Cognitive Task (Bloom): {rp['target_bloom_level'].upper()}")
            if rp.get("active_map"):
                zpd_lines.append(f"Thinking Map Pattern: {str(rp['active_map']).upper()}")
        
        full_prompt = band_a + band_b + band_c + zpd_lines
        return "\n".join(full_prompt)

        return "\n".join(lines)


# ================================================================
# GLOBAL SINGLETON
# ================================================================

_mandos_context: Optional[MandosContextService] = None


def get_mandos_context_service() -> MandosContextService:
    global _mandos_context
    if _mandos_context is None:
        _mandos_context = MandosContextService()
    return _mandos_context
